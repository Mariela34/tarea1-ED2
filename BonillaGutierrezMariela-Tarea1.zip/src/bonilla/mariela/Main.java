package bonilla.mariela;

import bonilla.mariela.ui.Controller;

import java.io.*;

public class Main {
    public static void main(String[] args) throws IOException {
        Controller controller = new Controller();
        controller.runSystem();
    }
}

